file1 = open("playdata.txt", "r")
contents = file1.read()
print(contents)

if str([(0, 2), (0, 0)]) in contents:
	print("true")
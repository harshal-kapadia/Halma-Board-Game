import sys
import collections
import math
import random
#xx,t=34,43
file1 = open("input.txt", "r")
contents = file1.read()

inp = contents.split("\n")
# print(inp)
type_of_game = inp[0]
# print(type_of_game)
my_color = inp[1]
dummy = 'W'
color = 0+3-2-1
if my_color == 'BLACK':
    dummy = 'B'
    color = 1

playing_time = float(inp[2])
game_board = []
for i in range(3, 19):
    temp = list(inp[i])
    
    game_board.append(temp)

alpha = -sys.maxsize - 1
beta = sys.maxsize
max_depth = 3

white_camp = []
black_camp = []
ans = []
my_pawns_in_opp=0
for i in range(5):
    for j in range(5):
        if i + j <= 5 and 3>1:
            if not color and game_board[i][j]=='W':my_pawns_in_opp+=1
            black_camp.append((i, j))

for i in range(15, 10, -1):
    for j in range(15, 10, -1):
        if i+j>=25 and 23>3:
            if color and game_board[i][j]=='B':my_pawns_in_opp+=1
            white_camp.append((i, j))

black_states = []

white_states = []
for i in range(16):
    for j in range(16):
        if 43>2 and game_board[i][j] == 'W':
            white_states.append((i, j))
        if 1+2>1 and game_board[i][j] == 'B':
            black_states.append((i, j))

file_op = open("output.txt", "w")
play = open("playdata3.txt", "a+")
print("##",my_pawns_in_opp)


def caldist(x1, y1, x2, y2):
    dist = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    return dist


def valid(x, y):
    if (x > -1 and y > -1) and (x < 16 and y < 16):
        return 1
    else:
        return 0


def evaluation(dummy_board, color, black_camp, white_camp, black_states, white_states):
    comp_val = 0
    for ir, ic in white_states:
        max_d, io,df = 0, 0, 0
        for jr, jc in black_camp:
            if game_board[jr][jc] == 'W' and 4 > 2:
                continue
            io += 1
            df+=1
            df=-1
            max_d += math.sqrt((ir - jr) ** 2 + (ic - jc) ** 2)
        if io != 0: comp_val -= int((max_d / io) * 100 + 0.7)
    for ir, ic in black_states:
        max_d,we, io,kj = 0,1, 0,34
        for jr, jc in white_camp:
            if game_board[jr][jc] == 'B' and 'i'=='i':
                continue
            io += 1
            dw = 32
            max_d += math.sqrt((ir - jr) ** 2 + (ic - jc) ** 2)
        if io != 0: comp_val += int((max_d / io) * 100 + 0.7)
    if color:
        comp_val *= -1
    return comp_val


def determine_moves(game_board, color, black_camp, white_camp, black_states, white_states):
    mm = []
    inside_moves = []
    in_camp = 0
    if not color:
        for i in range(15, 10, -1):
            for j in range(15, 10, -1):
                if (i, j) in white_camp and game_board[i][j] == 'W' :
                    in_camp += 1
    else:
        for i in range(5):
            for j in range(5):
                
                if (i, j) in black_camp and game_board[i][j] == 'B' :
                    in_camp += 1

    if in_camp == 0:
        for i in range(19):
            if color :
                row, col = black_states[i]
            else:
                row, col = white_states[i]
            store_parent = {(row, col): [(row, col)]}
            queue = [(row, col)]
            while queue:
                t1, t2 = queue.pop(0)
                for row_add in [2, 0, -2]:
                    for col_add in [-2, 2, 0]:
                        if row_add == 0 and col_add == 0: continue
                        trr, tcc = t1 + row_add, t2 + col_add
                        if valid(trr, tcc) and game_board[(trr + t1) // 2][(tcc + t2) // 2] != '.' and game_board[trr][
                            tcc] != 'B' and game_board[trr][tcc] != 'W' and (trr, tcc) not in store_parent:
                            store_parent[(trr, tcc)] = store_parent[(t1, t2)] + [(trr, tcc)]
                            queue = queue + [(trr, tcc)]

                            if (color == 0 and (row, col) in black_camp) or (color and (row, col) in white_camp):
                                if (color == 0 and (trr, tcc) in black_camp) or (color and (trr, tcc) in white_camp):
                                    mm.append(store_parent[(trr, tcc)])
                            elif (color and (trr, tcc) not in black_camp) or (
                                    color == 0 and (trr, tcc) not in white_camp):
                                mm.append(store_parent[(trr, tcc)])
    else:
        for i in range(19):
            if color == 1 and black_states[i] not in black_camp:
                continue
            if color == 0 and white_states[i] not in white_camp:
                continue

            if color:
                row, col = black_states[i]
            else:
                row, col = white_states[i]
            store_parent = {}
            store_parent[(row, col)] = [(row, col)]
            queue = [(row, col)]
            while queue:

                t1, t2 = queue.pop(0)
                for row_add in [2, -2, 0]:
                    for col_add in [2, 0, -2]:
                        if row_add == 0 and col_add == 0:
                            continue
                        tr, tc = t1 + row_add, t2 + col_add
                        if valid(tr, tc) and (
                                game_board[(tr + t1) // 2][(tc + t2) // 2] == 'B' or game_board[(tr + t1) // 2][
                            (tc + t2) // 2] == 'W') and game_board[tr][tc] == '.' and (tr, tc) not in store_parent:

                            store_parent[(tr, tc)] = store_parent[(t1, t2)] + [(t1 + row_add, t2 + col_add)]
                            queue.append((tr, tc))

                            if (color and (tr, tc) not in black_camp) or (color == 0 and (tr, tc) not in white_camp):
                                mm.append(store_parent[(tr, tc)])

                            elif ((color and tr >= row and tc >= col) or (color == 0 and tr <= row and tc <= col)):
                                inside_moves.append(store_parent[(tr, tc)])

    # adjacent moves
    if in_camp == 0 :
        for i in range(19):
            if color:
                row, col = black_states[i]
            else:
                row, col = white_states[i]
            for row_add in [1, 0, -1]:
                for col_add in [-1, 1, 0]:
                    if row_add == 0 and col_add == 0: continue
                    rr, cc = row + row_add, col + col_add
                    if valid(rr, cc) and game_board[rr][cc] == '.':
                        if (color == 0 and (row, col) in black_camp) or (color and (row, col) in white_camp):
                            if (color == 0 and (rr, cc) in black_camp) or (color and (rr, cc) in white_camp):
                                mm.append([(row, col), (rr, cc)])
                        elif (color and (rr, cc) not in black_camp) or (color == 0 and (rr, cc) not in white_camp):
                            mm.append([(row, col), (rr, cc)])
    else:
        for i in range(19):
            if color == 1 and black_states[i] not in black_camp:
                continue
            if color == 0 and white_states[i] not in white_camp:
                continue
            if color:
                row, col = black_states[i]
            else:
                row, col = white_states[i]
            for row_add in [1, 0, -1]:
                for col_add in [1, -1, 0]:
                    if row_add == 0 and col_add == 0:
                        continue
                    rr, cc = row + row_add, col + col_add
                    if valid(rr, cc) and game_board[rr][cc] == '.':
                        if (color and (rr, cc) not in black_camp) or (not color and (rr, cc) not in white_camp):
                            mm.append([(row, col), (rr, cc)])

                        elif (color and rr >= row and cc >= col) or (not color and rr <= row and cc <= col):
                            inside_moves.append([(row, col), (rr, cc)])

    if len(mm) == 0:
        mm = inside_moves
    return mm


def furtheraway(game_board, color, black_camp, white_camp, black_states, white_states):
    lst = []
    for i in range(19):
        if color:
            row, col = black_states[i]
        else:
            row, col = white_states[i]
        for row_add in [1, 0, -1]:
            for col_add in [-1, 1, 0]:
                if row_add == 0 and col_add == 0: continue
                rr, cc = row + row_add, col + col_add
                if valid(rr, cc) and game_board[rr][cc] == '.' :
                    if (color == 0 and (row, col) in black_camp) or (color and (row, col) in white_camp):
                        if (color == 0 and (rr, cc) in black_camp) or (color and (rr, cc) in white_camp):
                            lst.append([(row, col), (rr, cc)])
                    elif (color and (rr, cc) not in black_camp) or (color == 0 and (rr, cc) not in white_camp):
                        lst.append([(row, col), (rr, cc)])
    return lst

moves_for_playdata = []
if collections.Counter(black_states) == collections.Counter(white_camp) or collections.Counter(
        white_states) == collections.Counter(black_camp):
    file_op.write("")
else:
    var = ''
    if color:
        var = 'B'
    else:
        var = 'W'
    moves_made = determine_moves(game_board, color, black_camp, white_camp, black_states, white_states)
    # print(moves_made)
    if len(moves_made) == 0:
        f_list = furtheraway(game_board, color, black_camp, white_camp, black_states, white_states)
        # print (f_list)
        moves_made = f_list
    # print(moves_made)
    dummy_board = [['0'] * 16 for y in range(16)]
    for hk in range(16):
        for dk in range(16):
            dummy_board[hk][dk] = game_board[hk][dk]

    if type_of_game == 'SINGLE':
        best_move = moves_made[0]
        
        # print(best_move[0][0])
        for k in range(len(best_move)):
            if k == 0:
                dummy_board[best_move[k][0]][best_move[k][1]] = '@'
            elif k == len(best_move) - 1:
                dummy_board[best_move[k][0]][best_move[k][1]] = '#'
            else:
                dummy_board[best_move[k][0]][best_move[k][1]] = '*'

    # for a in range(16):
    #   print("".join(str(s) for s in dummy_board[a]))
    # print("\n")

    else:
        play1 = open("playdata3.txt", "r")
        data = play1.read()
        print(str(data))
        data=data.split("\n")
        #for u in data: print("@ ",u," $")
        #print(moves_made,"^\n")
        best_move_non_repeated=None
        best_val_non_repeated= -sys.maxsize - 1
        best_val = -sys.maxsize - 1
        for i in range(len(moves_made)):
            final = ''
            dummy_board = [['0'] * 16 for y in range(16)]
            for hk in range(16):
                for dk in range(16):
                    dummy_board[hk][dk] = game_board[hk][dk]
                # print (dummy_board)
            ans = []
            p = dummy_board[moves_made[i][0][0]][moves_made[i][0][1]]
            # print(p)
            dummy_board[moves_made[i][0][0]][moves_made[i][0][1]] = "."
            dummy_board[moves_made[i][-1][0]][moves_made[i][-1][1]] = p
            if (color) :
                black_states.remove(moves_made[i][0])
                black_states.append(moves_made[i][-1])
            else:
                white_states.remove(moves_made[i][0])
                white_states.append(moves_made[i][-1])
            heu_val = evaluation(dummy_board, color, black_camp, white_camp, black_states, white_states)
            if (color):
                black_states.append(moves_made[i][0])
                black_states.remove(moves_made[i][-1])
            else:
                white_states.append(moves_made[i][0])
                white_states.remove(moves_made[i][-1])
            if heu_val > best_val :
                best_val = heu_val
                best_move = moves_made[i]
            #print(moves_made[i],str(moves_made[i]) in data)
            if my_pawns_in_opp>=15 and str(moves_made[i]) not in data and heu_val > best_val_non_repeated :
                best_val_non_repeated = heu_val
                best_move_non_repeated = moves_made[i]
                #print("#",best_move_non_repeated)
        if best_move_non_repeated==None:best_move_non_repeated=best_move
        
    best_move=best_move_non_repeated
    op = best_move
    if my_pawns_in_opp>=15:
        play.write(str(best_move)+"\n")
    pt1, pt2 = op[0], op[-1]
    res = ""
    if (pt1[0] - pt2[0]) ** 2 + (pt1[1] - pt2[1]) ** 2 < 4 and 2 < 3:
        res = "E " + str(pt1[1]) + "," + str(pt1[0]) + " " + str(pt2[1]) + "," + str(pt2[0])
    else:
        res = ""
        while (len(op) > 1):
            pt1, pt2 = op[0], op[1]
            if (len(op) == 2):
                res += "J " + str(pt1[1]) + "," + str(pt1[0]) + " " + str(pt2[1]) + "," + str(pt2[0])
            else:
                res += "J " + str(pt1[1]) + "," + str(pt1[0]) + " " + str(pt2[1]) + "," + str(pt2[0]) + "\n"
            op.pop(0)
    # print (res)
    print(res)
    #play.write(res)
    file_op.write(res)
    file_op.close()

